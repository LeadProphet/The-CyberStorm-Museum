Read the whole thread at:
http://web.archive.org/web/20121128141129/http://forums.the-junkyard.net/showthread.php/8480-Cyberstorm-Single-Player-V1.2-(Now-it-actually-works!)


Cyberstorm Single Player V1.2 (Now it actually works!)

EDIT: It has been released! Get it here: link

Rename your original CSTORM.EXE file CSTORM_BACKUP.EXE and put this file in its place.

Just make sure you have version 1.1 already (if you do, Hotseat Game should be an option on the multiplayer menu). If you don't, the patch can be downloaded here, too: link

Hello CS fans!

Seraphim's release of a very thorough description of the cybrid models has enabled us to locate the designs for the official Cybrid Hercs inside the CSTORM.EXE file. We plan to create a mod of Cyberstorm, arming the Cybrids both more intelligently and more powerfully, to make the single player game more interesting.

This thread is intended to keep this project organized and running smoothly. The following is a list that I will keep current of who is doing what and what the overall plan for each segment is. In any post in this thread, please indicate the section names (which is in capital letters) relating to your post, and then list whatever suggestions you would like to make.

At this point, all modifications have been gathered. Further changes will undoubtedly be made, but we are ready to move on to testing.


SPECTERS: Borg_Down
ROLE: V1 - V6: Flanking attacker.
EF Cannons on V_1.

PARASITE: Crow!
ROLE: V1 - V6: Deal one hit quickly, then die.
It has a speed boosting device but also has the mining device just to be safe that the AI doesn't mess up.

CEREBRUS: Borg_Down
ROLE: V1 - V6: Support Herc. Various mortars once they are available.
Starting with version 3, these have targeting bonus devices, making other Cybrids better at aiming until they are destroyed.

ARACHNUS: Crow!
ROLE: V1 - V3: High speed shield downer.
V4 - V6: More like Parasite as EMPs and Neutron weapons combine.

GENOCITE: SiopaomanX
ROLE: V1 - V3: Generic, medium Herc with long range weapons and medium autocannons.
ROLE: V4 - V5: Plasma/Fusion Mortars replace autocannons.
V6: Returns to being more independent, as Hades provides most of the mortar-toting.
NOTE: Genocite V2 occured only one rank after V1! I have delayed V2 by one rank to compensate. I always wondered why I never saw any Genocite V1s.

MALIGNUS: Crow!
ROLE: V1 - V2: Heavy Herc , slightly weaker than Demon
ROLE: V3: Thermal Needler / area effect missiles
ROLE: V4 - V5: Fast attack plasma cannon toting Herc. V4 has Rapid Saturation Missiles.
ROLE: V6: SP1200s and HC Blasters with HK missiles.
Q: V3 is a bit strange, and I'd like to receive feedback on it. As a rank 7 Herc, I give it 4x Thermal Needler (small weapon, rank 9) and 2x Heavy Saturation Rockets (rank 10). All those weapons have a huge number of subhits, making it much more dangerous against light hercs than against heavies. All weapons are sub-par for their alleged rank, especially in the hands of the trigger-happy Cybrids.

HADES: Seraphim
ROLE: V1 - V2: Generic Heavy
ROLE: V3 - V6: various specialized distances. V6 has mortars.

NIHILUS: Crow!
ROLE: V1 - V6: Heavy assault; thick shields and armor, some ECM, and long range weapons.

VERMINIUS: SiopaomanX
ROLE: V1 - V3: Short range throw away self destructor.
We have not yet adopted any changes to these units.

TURRETS: Crow!
Non-heavy turrets had sucky computers; that has been fixed. Heavy turrets have been given Assault armor V3 onward, and it gets thicker for V4 and V5. Light turrets' lasers have in general been upgraded to medium size, and V5 has autocannons like the rest of the versions.

STRUCTURES: nobody assigned
Q: Do we upgrade the armor or shields on enemy structures?
A: I have thought about that for a while, and I think we should not. Killing a building before killing all cybrids/turrets is a strategic decision that, in the proper circumstances, should be encouraged and not punished. Besides, after all Cybrid threats are eliminated, who wants to have to sit around for multiple turns just to kill a harmless building?


FIRST SOLAR SYSTEM: Ranks 0 - 5.
Our upgrades on these Cybrids should focus on intelligent weapon choices using the new definitions of what the Cybrids can and can't mount. No more than one overdrive per Cybrid. We want 1. the start of the game to be easier than the end of the game, and 2. the first elite military mission to be playable.

SECOND SOLAR SYSTEM: Ranks 6 - 10.
The Cybrids here should be a challenge to defeat. Anyone have specific plans?

THIRD SOLAR SYSTEM: Ranks 11 - 13
The Cybrids here should be brutal; they should all be independently powerful, but they should work together in a way that makes them more than the sum of their parts. The special V6 versions should pull out all the stops; remember that the programmers broke the rules when designing them, so we can do the same and create Hercs that follow the Cybrid Herc designs in spirit but totally cheat in actual weapon and component mountings in order to produce the ultimate challenge. 


Last edited by Crow!; 09-03-2009 at 09:00 PM. 
